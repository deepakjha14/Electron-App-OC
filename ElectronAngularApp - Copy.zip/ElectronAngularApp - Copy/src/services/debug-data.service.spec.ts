import { TestBed, inject } from '@angular/core/testing';

import { DebugDataService } from './debug-data.service';

describe('DebugDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DebugDataService]
    });
  });

  it('should be created', inject([DebugDataService], (service: DebugDataService) => {
    expect(service).toBeTruthy();
  }));
});

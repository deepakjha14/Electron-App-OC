import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class DebugDataService{
  private debugDataSubjet: Subject<Object> = new Subject<Object>();
  private debugData : any;
  private flowDataSubjet: Subject<Object> = new Subject<Object>();
  private flowData = new Set();
  private imageDataSubjet: Subject<Object> = new Subject<Object>();
  private imageData = new Set();
  
  constructor(private http: HttpClient) { 
    this.http.get('http://localhost:8000/electronAPIData').subscribe(response=>{
      this.debugDataSubjet.next(response);
      this.debugData = response;
      this.debugData.paneData.forEach(element => {
        this.flowData.add(element.flowId);
        this.imageData.add(element.imageId);
      });
      this.flowDataSubjet.next(this.flowData);
      this.imageDataSubjet.next(this.imageData)
    });
  }

  public getFlowData(){
    //let uniqueFlowID = new Set();
    return this.flowDataSubjet;
  }

  public getImageData(){
    return this.imageDataSubjet;
  }

  public getDebugData(){
    return this.debugDataSubjet;
  }
}

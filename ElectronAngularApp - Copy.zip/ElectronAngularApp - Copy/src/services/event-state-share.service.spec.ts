import { TestBed, inject } from '@angular/core/testing';

import { EventStateShareService } from './event-state-share.service';

describe('EventStateShareService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EventStateShareService]
    });
  });

  it('should be created', inject([EventStateShareService], (service: EventStateShareService) => {
    expect(service).toBeTruthy();
  }));
});

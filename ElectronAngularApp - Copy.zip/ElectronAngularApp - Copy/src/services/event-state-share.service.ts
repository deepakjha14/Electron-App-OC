import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class EventStateShareService {
  private flowStateShare: Subject<Number> = new Subject<Number>();
  private imageStateShare: Subject<Number> = new Subject<Number>();
  
  constructor() { }

  public changeFlow(selectedFlow: Number){
    console.log(selectedFlow);
    //debugger;
    this.flowStateShare.next(selectedFlow);
  }

  public changeImage(selectedImage: Number){
    this.imageStateShare.next(selectedImage);
  }

  public getFlow(){
    return this.flowStateShare;
  }

}

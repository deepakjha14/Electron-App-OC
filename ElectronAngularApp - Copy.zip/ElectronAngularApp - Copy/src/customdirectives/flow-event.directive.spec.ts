import { FlowEventDirective } from './flow-event.directive';

describe('FlowEventDirective', () => {
  it('should create an instance', () => {
    const directive = new FlowEventDirective();
    expect(directive).toBeTruthy();
  });
});

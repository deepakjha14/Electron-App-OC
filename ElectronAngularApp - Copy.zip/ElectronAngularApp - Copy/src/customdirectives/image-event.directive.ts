import { Directive } from '@angular/core';

@Directive({
  selector: '[appImageEvent]'
})
export class ImageEventDirective {

  constructor() { }

}

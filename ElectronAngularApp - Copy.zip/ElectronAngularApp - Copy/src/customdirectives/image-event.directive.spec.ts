import { ImageEventDirective } from './image-event.directive';

describe('ImageEventDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageEventDirective();
    expect(directive).toBeTruthy();
  });
});

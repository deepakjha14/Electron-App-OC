import { CodeEventDirective } from './code-event.directive';

describe('CodeEventDirective', () => {
  it('should create an instance', () => {
    const directive = new CodeEventDirective();
    expect(directive).toBeTruthy();
  });
});

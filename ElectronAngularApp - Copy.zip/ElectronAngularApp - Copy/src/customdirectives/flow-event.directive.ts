import { Directive, Input, ElementRef, OnInit, Renderer2} from '@angular/core';
import { EventStateShareService } from '../services/event-state-share.service';

@Directive({
  selector: '[appFlowEvent]'
})
export class FlowEventDirective implements OnInit{
  @Input() appFlowEvent;
  flowId: Number;
  constructor(private rend: Renderer2, private el: ElementRef, private evtShareSer: EventStateShareService) {
    //debugger; 
    //console.log(this.el, this.appFlowEvent);
    this.evtShareSer.getFlow().subscribe(newId=>{
      this.flowId = newId;
      console.dir(this.el.nativeElement.id);
      //debugger;
      //this.rend.addClass(this.el.nativeElement[this.flowId.toString()], 'myTestClass');
      this.el.nativeElement.style.color="BLACK";
      //this.el.nativeElement.style.color="RED";
      document.getElementById(this.flowId.toString()).style.color = "RED";
      //this.el.nativeElement.style.backgroundcolor="PINK";
    });
  }
  ngOnInit(){
    this.el.nativeElement.id = this.appFlowEvent;
    console.log(this.el, this.appFlowEvent);
    //debugger;
  }
}

import { Directive, HostListener, ElementRef, Input, EventEmitter, Output } from '@angular/core';
import { EventStateShareService } from '../services/event-state-share.service';

@Directive({
  selector: '[appCodeEvent]'
})
export class CodeEventDirective {
  @Input() appCodeEvent;
  @Output() codeHover = new EventEmitter();
  constructor(private el: ElementRef, private evtShareService: EventStateShareService) { 
    //el.nativeElement.style.backgroundColor="BLUE";
  }

  @HostListener('mouseenter') onmouseover(){
    this.el.nativeElement.style.color="RED";
    console.log(this.appCodeEvent);
    //debugger;
    this.evtShareService.changeFlow(this.appCodeEvent.flowId);
    //this.codeHover.emit({"sharedData":this.appCodeEvent});
  }

  @HostListener('mouseleave') onmouseleave(){
    this.el.nativeElement.style.color="BLACK";
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { DebugDataService} from '../services/debug-data.service';
import { EventStateShareService } from '../services/event-state-share.service';

import { CodeComponentComponent } from '../applicationComponents/code-component/code-component.component';
import { FlowComponentComponent } from '../applicationComponents/flow-component/flow-component.component';
import { ImageComponentComponent } from '../applicationComponents/image-component/image-component.component';
import { CodeEventDirective } from '../customdirectives/code-event.directive';
import { FlowEventDirective } from '../customdirectives/flow-event.directive';
import { ImageEventDirective } from '../customdirectives/image-event.directive';


@NgModule({
  declarations: [
    AppComponent,
    CodeComponentComponent,
    FlowComponentComponent,
    ImageComponentComponent,
    CodeEventDirective,
    FlowEventDirective,
    ImageEventDirective
  ],
  imports: [
    HttpClientModule,
    BrowserModule
  ],
  providers: [DebugDataService, EventStateShareService],
  bootstrap: [AppComponent]
})
export class AppModule { }

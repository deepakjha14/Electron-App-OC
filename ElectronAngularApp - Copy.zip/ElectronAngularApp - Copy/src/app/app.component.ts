import { Component, OnInit } from '@angular/core';
import { DebugDataService } from '../services/debug-data.service';
import { resData } from '../interfaces/resData';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  codeData;
  flowData;
  constructor(private debugData: DebugDataService){
    this.debugData.getDebugData().subscribe((respData: resData)=>{
      //debugger;
      this.codeData = respData.paneData;
    });
    this.debugData.getFlowData().subscribe(flDta=>{
      this.flowData = flDta;
    });
  }
  ngOnInit(){
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowComponentComponent } from './flow-component.component';

describe('FlowComponentComponent', () => {
  let component: FlowComponentComponent;
  let fixture: ComponentFixture<FlowComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

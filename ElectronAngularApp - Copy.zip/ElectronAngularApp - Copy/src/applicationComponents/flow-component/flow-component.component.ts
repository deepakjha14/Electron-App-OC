import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flow-component',
  templateUrl: './flow-component.component.html',
  styleUrls: ['./flow-component.component.css']
})
export class FlowComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { DebugDataService } from '../../services/debug-data.service';

@Component({
  selector: 'app-code-component',
  templateUrl: './code-component.component.html',
  styleUrls: ['./code-component.component.css']
})
export class CodeComponentComponent{
  codeData: any;
  
  constructor(private dataService : DebugDataService) { 
    this.codeData = this.dataService.getDebugData();
  }
  
}

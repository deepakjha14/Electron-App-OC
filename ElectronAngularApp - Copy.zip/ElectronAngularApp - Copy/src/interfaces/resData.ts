export interface resData{
    paneData: Array<allWindow>;
}

export interface allWindow{
    code: String;
    flow:Number;
    image:Number;
}